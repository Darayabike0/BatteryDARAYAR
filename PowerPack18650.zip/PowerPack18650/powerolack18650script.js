// ข้อมูลสินค้าจากไฟล์ CSV ที่คุณให้มา
const products = [
    { type: "2S", voltage: "7.4V", capacity: "2000 mAh", energy: "14.8 Wh", usage: "รถบังคับ, ลำโพงบลูทูธ, ไฟฉาย" },
    { type: "3S", voltage: "11.1V", capacity: "2000 mAh", energy: "22.2 Wh", usage: "กล้องวงจรปิด, หุ่นยนต์ดูดฝุ่น" },
    { type: "4S", voltage: "14.8V", capacity: "2000 mAh", energy: "29.6 Wh", usage: "เครื่องเสียงพกพา, โดรน" },
    { type: "5S", voltage: "18.5V", capacity: "2000 mAh", energy: "37.0 Wh", usage: "สว่านไร้สาย, พาวเวอร์แบงค์" },
    { type: "6S", voltage: "22.2V", capacity: "2000 mAh", energy: "44.4 Wh", usage: "สกู๊ตเตอร์ไฟฟ้า, เครื่องมือช่าง" },
    { type: "10S", voltage: "37.0V", capacity: "2000 mAh", energy: "74.0 Wh", usage: "E-Bike, สกู๊ตเตอร์มาตรฐาน" }
];

// ฟังก์ชันสร้างการ์ดสินค้า
function renderProducts() {
    const grid = document.getElementById('product-grid');
    
    products.forEach(p => {
        const card = document.createElement('div');
        card.className = 'card';
        
        const usages = p.usage.split(',').map(u => `<span class="usage-tag">${u.trim()}</span>`).join('');
        
        card.innerHTML = `
            <h3>Darayar ${p.type}</h3>
            <p><strong>แรงดัน:</strong> ${p.voltage}</p>
            <div class="specs">
                <p>ความจุ: ${p.capacity}</p>
                <p>พลังงานรวม: ${p.energy}</p>
            </div>
            <div>${usages}</div>
        `;
        grid.appendChild(card);
    });
}

// ระบบส่งฟอร์ม (จำลองการทำงาน)
document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = {
        name: document.getElementById('name').value,
        subject: document.getElementById('subject').value,
        message: document.getElementById('message').value
    };

    console.log("ส่งข้อมูลไปยัง GitHub/Database:", formData);
    alert("ขอบคุณคุณ " + formData.name + " ทางเราได้รับข้อความแล้ว!");
    this.reset();
});

// รันเมื่อโหลดหน้าเว็บ
window.onload = renderProducts;